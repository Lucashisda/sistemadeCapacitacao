package aplicacao;

import entidade.ServidorPublico;

public class Programa {
    public static void main(String [] args ){
        ServidorPublico isabela = new ServidorPublico();
    isabela.setName("Isabela");
    isabela.setCargo("Auditor");
    isabela.setOrgao("ANVISA");
    isabela.setLotacao("Brasilia");
    isabela.setEmail("isabela@gmail.com");

    System.out.println("Servidor: " + isabela.getNome);








    }
}
